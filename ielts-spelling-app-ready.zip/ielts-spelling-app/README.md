# IELTS Spelling Platform

IELTS Spelling Practice Platform - 500+ words with British pronunciation

## Setup

1. Install dependencies: `npm install`
2. Create `.env.local` with your Stripe key
3. Run: `npm run dev`
4. Open: http://localhost:3000

## Build

`npm run build`

## Deploy to Vercel

Push to GitHub, connect to Vercel, done!